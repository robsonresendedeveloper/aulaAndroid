package com.example.aulajokenpo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class ResultadoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        Bundle dados = getIntent().getExtras();
        int numero = dados.getInt("numero");

        ImageView imgResultado = findViewById(R.id.imgResultado);
        Button btnVoltar = findViewById(R.id.btnVoltar);

        if(numero == 1)
            imgResultado.setImageResource(R.drawable.pedra);
        else if(numero == 2)
            imgResultado.setImageResource(R.drawable.papel);
        else
            imgResultado.setImageResource(R.drawable.tesoura);

        btnVoltar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}

